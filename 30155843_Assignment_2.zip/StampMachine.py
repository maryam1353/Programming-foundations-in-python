from stamp import *
from datetime import date
from _datetime import datetime
import pandas as pd
shoppingCart=[]

if __name__ == "__main__":
    pass

def addItem():
    item = Stamp()
    item.construct_stamp_user()
    itemToAdd = True
    for st in shoppingCart:
        if(st == item):
            ch = input("You are adding duplicate item in the cart. Do you want to continue Y/N")
            if(ch=="N" or ch=="n"):
                print("try adding another item")
                itemToAdd=False
            break
    if(itemToAdd==True):
        item.calc_unit_price()
        item.update_unit_price()
        shoppingCart.append(item)
        
def viewShoppingCart():
    totalPrice =0
    itemCount =1
    print("############### Shopping Cart ####################################################################")
    for item in shoppingCart:        
        print("Item No: %s  Item Type: %-20s  Weight: %-20s   Destination: %-20s   Unit price%-20s" % (itemCount, item.item_type,item.weight, item.country_name,item.unit_price));
        totalPrice = totalPrice+item.calc_unit_price()
        itemCount =itemCount +1
    print("##################################################################################################")
    print("Total Price : ", totalPrice)
    print("##################################################################################################")

def ammendItem():
    itemChoice = input("Which Cart Item you would like to ammend ? ")
    if(int(itemChoice)<=len(shoppingCart)):
        weight = input("Please enter new weight")
        item = shoppingCart[int(itemChoice)-1]
        item.update_weight(float(weight))

def removeItem():
    itemToRemove = input("Please provide item number you want to remove : ")
    if(int(itemToRemove) <= len(shoppingCart)):
        item = shoppingCart[int(itemToRemove)-1]
        shoppingCart.remove(item)
    else:
        print("Provided Item number is greater than the total number of item in the cart")

def printInvoice():
    df = pd.read_csv('sales_history.csv',header=None)
    #Get the first Column in the form of dictionary
    seqDict = df[0]
    sequence=[]
    for row in seqDict:
        sequence.append(row)
    newSequence = sequence[len(sequence)-1]
    
    totalPrice =0;
    itemCount =1;
    filename1 = datetime.now().strftime("%Y%m%d-%H%M%S")
    file = open(filename1+".txt", "w+")
    file1 = open("sales_history.csv","a")
    print("-----------------------------Invoice----------------------------------")
    file.write("-----------------------------Invoice----------------------------------\n");
    for item in shoppingCart:        
        print("Item No: %s  Item Type: %-8s  Weight: %-6s   Destination: %-20s   Unit price: %-5s" % (itemCount, item.item_type,item.weight, item.country_name,item.unit_price));
        file.write("Item No: "+str(itemCount)+"      "+"Item Type: "+str(item.item_type)+"    "+"Weight: "+str(item.weight)+"    "+"Destination: "+str(item.country_name)+"   "+"Unit price:"+str(item.unit_price)+"\n")
        file1.write("\n"+newSequence+","+str(datetime.now())[:19]+","+str(item.item_type)+","+str(item.weight)+","+str(item.country_name)+","+str(item.unit_price))
        itemCount=itemCount+1
        totalPrice = totalPrice+item.calc_unit_price()
    print("Total cost : ",totalPrice)
    print("----------------------------End Invoice-------------------------------\n")
    file.write("----------------------------End Invoice-------------------------------\n");
    print("-------------Purchased Stamp-----------\n")
    file.write("-------------Purchased Stamp-----------\n");
    print("---------------------------------------")
    file.write("---------------------------------------\n");
    print("Economy Letter")
    file.write("Economy Letter\n");
    for item in shoppingCart:
        if(item.item_type=="letter"):
            print("Destination: %-20s  Weight: %-20s" % (item.country_name, item.weight)); 
            file.write("Destination: "+item.country_name+"     "+"Weight: "+str(item.weight)+"\n")
    print("---------------------------------------\n")
    file.write("---------------------------------------\n");
    print("---------------------------------------")
    file.write("---------------------------------------\n");
    print("Standard Parcel")
    file.write("Standard Parcel\n");
    for item in shoppingCart:
        if(item.item_type=="parcel"):
            print("Destination: %-20s  Weight: %-20s" % (item.country_name, item.weight)); 
            file.write("Destination: "+item.country_name+"     "+"Weight: "+str(item.weight)+"\n")
    print("---------------------------------------\n")
    file.write("---------------------------------------\n");   
    file1.close()
    file.close()
print("Welcome to Shopping Stamp Shopping application")
print("Please follow the Menu Instruction")
while True:
    print("##################################################")
    print("Add an item to the shopping cart       :1")
    print("View shopping cart                     :2")
    print("Amend an item                          :3")
    print("Remove an item from the shopping cart  :4")
    print("Checkout                               :5")
    print("Quit                                   :Q")
    print("##################################################")
    userChoice = input("Please provide your choice")
    
    if(userChoice == "1"):
        addItem() 
              
    elif(userChoice == "2"):
        viewShoppingCart()
        
    elif(userChoice == "3"):
        ammendItem()
        print()
    elif(userChoice=="4"):
        removeItem()
    elif(userChoice=="5"):
        printInvoice()
        break
    elif(userChoice=="Q" or userChoice == "q"):
        break
    else:
        print("Invalid input, Please try again")

